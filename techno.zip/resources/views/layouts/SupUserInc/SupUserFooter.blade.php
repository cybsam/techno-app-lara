<!-- ======= Footer ======= -->
<footer id="footer" class="footer">
    <div class="copyright">
       
      &copy; 2006-{{ now()->year }} <strong><span><a href="{{ route('frontEndIndex') }}">Techno Apogee Limited </a></span></strong> | All Rights Reserved
    </div>
    <div class="credits">
      Developed by <a href="#">CybSam</a><p>Laravel v{{ Illuminate\Foundation\Application::VERSION }} (PHP v{{ PHP_VERSION }})</p>
    </div>
  </footer><!-- End Footer -->
