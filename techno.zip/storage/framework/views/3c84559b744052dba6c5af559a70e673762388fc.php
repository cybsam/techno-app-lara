<!-- ======= Footer ======= -->
<footer id="footer" class="footer">
    <div class="copyright">
       
      &copy; 2006-<?php echo e(now()->year); ?> <strong><span><a href="<?php echo e(route('frontEndIndex')); ?>">Techno Apogee Limited </a></span></strong> | All Rights Reserved
    </div>
    <div class="credits">
      Developed by <a href="#">CybSam</a><p>Laravel v<?php echo e(Illuminate\Foundation\Application::VERSION); ?> (PHP v<?php echo e(PHP_VERSION); ?>)</p>
    </div>
  </footer><!-- End Footer -->
<?php /**PATH C:\Users\My Computer\Documents\NewVersionTechnoApogee\en\resources\views/layouts/SupUserInc/SupUserFooter.blade.php ENDPATH**/ ?>