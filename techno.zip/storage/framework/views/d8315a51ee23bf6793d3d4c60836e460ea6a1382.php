    <!-- ======= Sidebar ======= -->
        <aside id="sidebar" class="sidebar">

        <ul class="sidebar-nav" id="sidebar-nav">

        <li class="nav-item">
            <a class="nav-link " href="<?php echo e(route('Administrator.index')); ?>">
            <i class="bi bi-grid"></i>
            <span>Dashboard</span>
            </a>
        </li><!-- End Dashboard Nav -->

        <li class="nav-heading">Apps</li>




        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#email-nav" data-bs-toggle="collapse" href="#">
            <i class="bi bi-envelope"></i><span>Emails</span><i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="email-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                <li>
                    <a href="#">
                    <i class="bi bi-circle"></i><span>Compose</span>
                    </a>
                </li>
            <li>
                <a href="#">
                <i class="bi bi-download"></i><span>Inbox</span>
                </a>
            </li>
            <li>
                <a href="#">
                <i class="bi bi-circle"></i><span>Drifts</span>
                </a>
            </li>
            <li>
                <a href="#">
                <i class="bi bi-circle"></i><span>Trash</span>
                </a>
            </li>
            </ul>
        </li>

        <li class="nav-heading">Article</li>
        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
            <i class="bi bi-menu-button-wide"></i><span>Post Article</span><i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                
            <li>
                
            </li>
            <li>
                
            </li>
            <li>
                
            </li>


            </ul>
        </li><!-- End Components Nav -->
            
        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#forms-nav" data-bs-toggle="collapse" href="#">
            <i class="bi bi-journal-text"></i><span>Pending Article <b style="color:red;">5</b></span><i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="forms-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
            <li>
                <a href="">
                <i class="bi bi-circle"></i><span>Pending Article <b style="color:red;">5</b> </span>
                </a>
            </li>

            </ul>
        </li>
        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#charts-nav" data-bs-toggle="collapse" href="#">
            <i class="bi bi-bar-chart"></i><span>Catagory</span><i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="charts-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
            
            </ul>
        </li><!-- End Charts Nav -->

        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#catagory-nav" data-bs-toggle="collapse" href="#">
            <i class="bi bi-gem"></i><span>Super Catagory</span><i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="catagory-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
            
            </ul>
        </li>

        <li class="nav-heading">Users</li>
        <li class="nav-item <?php if(url()->current() == route('SupUser.ListUsers')): ?> active <?php endif; ?>">
            <a class="nav-link collapsed" data-bs-target="#users-nav" data-bs-toggle="collapse" href="#">
            <i class="bi bi-person-lines-fill"></i><span>Users</span><i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="users-nav" class="nav-content collapse active" data-bs-parent="#sidebar-nav">
            <li>
                <a href="<?php echo e(route('SupUser.ListUsers')); ?>" class="<?php if(url()->current() == route('SupUser.ListUsers')): ?> active <?php endif; ?>">
                <i class="bi bi-circle"></i><span>Users List</span>
                </a>
            </li>
            <li>
                <a href="">
                <i class="bi bi-circle"></i><span>Archive Users</span>
                </a>
            </li>
            <li>
                <a href="">
                <i class="bi bi-circle"></i><span>Block Users</span>
                </a>
            </li>
            </ul>
        </li>




        <li class="nav-heading">Settings</li>
        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#settings-nav" data-bs-toggle="collapse" href="#">
            <i class="bi bi-gear"></i><span>Settings</span><i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="settings-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
            <li>
                <a href="" >
                <i class="bi bi-circle"></i><span>Main Settings</span>
                </a>
            </li>
            <li>
                <a href="">
                <i class="bi bi-circle"></i><span>Find Us</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('SupUser.SetingsAboutUsInfo')); ?>" class="<?php if(url()->current() == route('SupUser.SetingsAboutUsInfo')): ?> active <?php endif; ?>">
                <i class="bi bi-circle"></i><span>About Us Info</span>
                </a>
            </li>
            <li>
                <a href="">
                <i class="bi bi-circle"></i><span>Terms Of Condition</span>
                </a>
            </li>

            </ul>
        </li>
        <li class="nav-heading">Pages</li>
        <li class="nav-item">
            <a class="nav-link collapsed" href="pages-faq.html">
            <i class="bi bi-question-circle"></i>
            <span>F.A.Q</span>
            </a>
        </li><!-- End F.A.Q Page Nav -->
        
        <li class="nav-item">
            <a class="nav-link collapsed" href="">
            <i class="bi bi-envelope"></i>
            <span>Contact Message <span style="color:red;">6</span></span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link collapsed" target="blank" href="<?php echo e(route('frontEndIndex')); ?>">
            <i class="bi bi-dash-circle"></i>
            <span>View Site</span>
            </a>
        </li><!-- End Error 404 Page Nav -->

        <li class="nav-item">
            <a class="nav-link collapsed" href="<?php echo e(route('dashboard.blank')); ?>">
            <i class="bi bi-file-earmark"></i>
            <span>Blank</span>
            </a>
        </li><!-- End Blank Page Nav -->
    </ul>
</aside><!-- End Sidebar-->
<?php /**PATH C:\Users\My Computer\Documents\NewVersionTechnoApogee\en\resources\views/layouts/SupUserInc/SupUserSide.blade.php ENDPATH**/ ?>