
<?php $__env->startSection('title', 'Users Page - Techno Apogee Limited'); ?>
<?php $__env->startSection('SupUserContent'); ?>

    <div class="pagetitle">
        <h1>Users</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('Administrator.index')); ?>">Dashboard</a></li>

                <li class="breadcrumb-item active">Users</li>
            </ol>
        </nav>
    </div>

    <div class="card">
        <div class="card-body">
            <h5 class="card-title">
                Users List
                <div class="float-right">
                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addusermodal">
                        + User
                    </button>
                </div>
                 
            </h5>
            
            <?php if(Session::get('regSuccAdmin')): ?>
                <div class="alert alert-primary bg-primary text-light border-0 alert-dismissible fade show" role="alert">
                    <?php echo e(Session::get('regSuccAdmin')); ?>

                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"
                        aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <?php if(Session::get('regErroradmin')): ?>
                <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show" role="alert">
                    <?php echo e(Session::get('regErroradmin')); ?>

                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"
                        aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <!-- Default Tabs -->
            <ul class="nav nav-tabs d-flex" id="myTabjustified" role="tablist">
                <li class="nav-item flex-fill" role="presentation">
                    <button class="nav-link text-center w-100 active" id="home-tab" href="" data-bs-toggle="tab"
                        data-bs-target="#home-justified" type="button" role="tab" aria-controls="home"
                        aria-selected="true">Users</button>

                </li>
                <li class="nav-item flex-fill" role="presentation">
                    <button class="nav-link w-100" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile-justified"
                        type="button" role="tab" aria-controls="profile" aria-selected="false">Admin</button>
                </li>
                
            </ul>
            <div class="tab-content pt-2" id="myTabjustifiedContent">
                <div class="tab-pane fade show active" id="home-justified" role="tabpanel" aria-labelledby="home-tab">


                    <table class="table table-hover datatable table-sm">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">username</th>
                                <th scope="col">Email</th>
                                <th scope="col">Image</th>
                                <th scope="col">Verified</th>
                                <th scope="col">is active</th>
                                <th scope="col">create</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>


                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="table-light">
                                    <th scope="row"><a href="#">#<?php echo e($users->id); ?></a></td>
                                    <td><?php echo e(Str::limit($users->name,10)); ?></a></td>
                                    <td><a class="" href=""><span>@</span><?php echo e(Str::limit($users->username,6)); ?></a></td>
                                    <td><a href="mailto:<?php echo e($users->email); ?>"><?php echo e($users->email); ?></a></td>
                                    <td><img src="<?php echo e(asset('image/users')); ?>/<?php echo e($users->user_image); ?>" height="35px" width="35px" alt=""></td>
                                    <td>
                                        <?php if($users->email_verified == 1): ?>
                                            <i class="bi bi-patch-check-fill text-primary"></i>
                                        <?php else: ?>
                                            <i class="bi bi-patch-exclamation text-danger"></i>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td>
                                        <div class="form-check form-switch">
                                            <input type="checkbox" class="form-check-input is_active_switch" id="switch[<?php echo e($key); ?>]" data-id="<?php echo e($users->id); ?>" <?php echo e($users->is_active ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="switch[<?php echo e($key); ?>]"></label>
                                        </div>
                                    </td>
                                    <td><?php echo e($users->created_at->diffForHumans()); ?></td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <button type="button" data-bs-toggle="modal" data-bs-target="#updateModal" data-id="<?php echo e($users->id); ?>" data-name="<?php echo e($users->name); ?>" data-username="<?php echo e($users->username); ?>" data-email="<?php echo e($users->email); ?>" data-role_int="<?php echo e($users->role_int); ?>" data-role="<?php echo e($users->role); ?>" class="btn btn-warning">
                                                <i class="bi bi-pencil-square" aria-hidden="true"></i>
                                            </button>
                                            <button type="button" data-bs-toggle="modal" data-bs-target="#deleteUser" data-id="<?php echo e($users->id); ?>" class="btn btn-danger">
                                                <i class="bi bi-trash" aria-hidden="true"></i>
                                            </button>
                                        </div>
                                        
                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                        <tfoot>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">username</th>
                                <th scope="col">Email</th>
                                <th scope="col">Image</th>
                                <th scope="col">Verified</th>
                                <th scope="col">is active</th>
                                <th scope="col">create</th>
                                <th scope="col">Action</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <div class="tab-pane fade" id="profile-justified" role="tabpanel" aria-labelledby="profile-tab">
                    <table class="table table-hover datatable table-sm">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">username</th>
                                <th scope="col">Email</th>
                                <th scope="col">Image</th>
                                <th scope="col">Verified</th>
                                <th scope="col">is active</th>
                                <th scope="col">create</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $Admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="table-light">
                                    <th scope="row"><a href="#">#<?php echo e($admin->id); ?></a></td>
                                    <td><?php echo e(Str::limit($admin->name,10)); ?></td>
                                    <td><a class="" href=""><span>@</span><?php echo e(Str::limit($admin->username,6)); ?></a></td>
                                    <td><a href="mailto:<?php echo e($admin->email); ?>"><?php echo e($admin->email); ?></a></td>
                                    <td><img src="<?php echo e(asset('image/users')); ?>/<?php echo e($admin->user_image); ?>" height="35px" width="35px" alt=""></td>
                                    <td>
                                        <?php if($admin->email_verified == 1): ?>
                                            <i class="bi bi-patch-check-fill text-primary"></i>
                                        <?php else: ?>
                                            <i class="bi bi-patch-exclamation text-danger"></i>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td>
                                        
                                        <div class="form-check form-switch">
                                            <input type="checkbox" class="form-check-input is_active_switch" id="switch[<?php echo e($key); ?>]" data-id="<?php echo e($admin->id); ?>" <?php echo e($admin->is_active ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="switch[<?php echo e($key); ?>]"></label>
                                        </div>
                                        
                                    </td>
                                    <td><?php echo e($admin->created_at->diffForHumans()); ?></td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <button type="button" data-bs-toggle="modal" data-bs-target="#adminUpdateModal" data-admin_id="<?php echo e($admin->id); ?>" data-admin_name="<?php echo e($admin->name); ?>" data-admin_username="<?php echo e($admin->username); ?>" data-admin_email="<?php echo e($admin->email); ?>" data-admin_role_int="<?php echo e($admin->role_int); ?>" data-admin_role="<?php echo e($admin->role); ?>" class="btn btn-warning">
                                                <i class="bi bi-pencil-square" aria-hidden="true"></i>
                                            </button>
                                            <button type="submit" data-bs-toggle="modal" data-bs-target="#deleteUser" data-id="<?php echo e($admin->id); ?>" class="btn btn-danger">
                                                <i class="bi bi-trash" aria-hidden="true"></i>
                                            </button>
                                        </div>
                                        
                                        

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                        <tfoot>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">username</th>
                                <th scope="col">Email</th>
                                <th scope="col">Image</th>
                                <th scope="col">Verified</th>
                                
                                <th scope="col">is active</th>
                                <th scope="col">create</th>
                                <th scope="col">Action</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                
            </div><!-- End Default Tabs -->

        </div>
    </div>





    

    </div>
    </div>
    

    <?php echo $__env->make('dashboard.users.partials.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php echo $__env->make('dashboard.users.partials.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.SupUserMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\My Computer\Documents\NewVersionTechnoApogee\en\resources\views/dashboard/users/index.blade.php ENDPATH**/ ?>